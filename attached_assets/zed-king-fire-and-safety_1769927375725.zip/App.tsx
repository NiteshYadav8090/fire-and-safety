
import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  ArrowRight, 
  CheckCircle, 
  ShieldCheck, 
  Users, 
  Award,
  ChevronRight,
  Menu,
  X,
  MessageCircle,
  PhoneCall,
  Flame,
  Info,
  Calendar,
  Lock,
  Plus,
  Minus,
  Search,
  Bell,
  Droplets,
  Settings,
  GraduationCap,
  FileCheck
} from 'lucide-react';
import { SERVICES, PROJECTS, CERTIFICATIONS, CLIENTS, CONTACT_INFO, FAQ, GALLERY, BLOG_POSTS } from './constants';

// --- Shared UI Components ---

const SectionTitle = ({ title, subtitle, light = false }: { title: string, subtitle?: string, light?: boolean }) => (
  <div className="mb-16 text-center px-4">
    <h2 className={`text-3xl md:text-4xl font-black ${light ? 'text-white' : 'text-blue-900'} mb-6 leading-tight`}>{title}</h2>
    {subtitle && <p className={`max-w-3xl mx-auto text-lg ${light ? 'text-gray-200' : 'text-gray-600'} leading-relaxed`}>{subtitle}</p>}
    <div className={`h-1.5 w-24 ${light ? 'bg-white' : 'bg-red-600'} mx-auto mt-8 rounded-full`}></div>
  </div>
);

const Navbar = ({ activePage, setActivePage }: { activePage: string, setActivePage: (p: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'services', label: 'Services' },
    { id: 'about', label: 'About Us' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'projects', label: 'Our Work' },
    { id: 'contact', label: 'Contact' }
  ];

  const handleLinkClick = (id: string) => {
    setActivePage(id);
    setIsOpen(false);
    window.scrollTo(0, 0);
  };

  // Improved visibility: Navbar background appears slightly earlier or is always solid if preferred.
  // We'll use blue-900 text consistently as requested.
  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-2xl py-3' : 'bg-white/90 backdrop-blur-sm py-5'}`}>
      <div className="container mx-auto px-4 lg:px-8 flex justify-between items-center">
        <div 
          className="flex items-center space-x-3 cursor-pointer group"
          onClick={() => handleLinkClick('home')}
        >
          <div className="bg-red-600 p-2.5 rounded-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
            <ShieldCheck className="text-white w-7 h-7" />
          </div>
          <div className="flex flex-col -space-y-1">
            <span className={`text-xl md:text-2xl font-black tracking-tighter text-blue-900`}>
              ZED-KING
            </span>
            <span className="text-[10px] md:text-xs font-bold text-red-600 tracking-[0.2em] uppercase">
              Fire and Safety
            </span>
          </div>
        </div>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center space-x-10">
          {navLinks.map(link => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`font-bold text-sm uppercase tracking-widest transition-all hover:text-red-600 relative py-2 group ${
                activePage === link.id ? 'text-red-600' : 'text-blue-900'
              }`}
            >
              {link.label}
              <span className={`absolute bottom-0 left-0 w-full h-0.5 bg-red-600 transform origin-left transition-transform duration-300 ${activePage === link.id ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></span>
            </button>
          ))}
          <button 
            onClick={() => handleLinkClick('contact')}
            className="bg-red-600 text-white px-8 py-3.5 rounded-xl font-black text-sm uppercase tracking-widest hover:bg-red-700 transition-all shadow-xl hover:shadow-red-500/30 hover:-translate-y-1"
          >
            Get Expert Quote
          </button>
        </div>

        {/* Mobile Toggle */}
        <button className="lg:hidden p-2 rounded-lg" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="text-blue-900" /> : <Menu className="text-blue-900" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white fixed inset-0 z-[100] flex flex-col p-8 space-y-6">
          <div className="flex justify-between items-center mb-8">
            <div className="flex flex-col">
              <span className="text-2xl font-black text-blue-900 leading-none">ZED-KING</span>
              <span className="text-xs font-bold text-red-600 tracking-wider">Fire and Safety</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-2 bg-gray-100 rounded-full"><X className="text-blue-900" /></button>
          </div>
          {navLinks.map(link => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`text-left font-black text-3xl flex items-center justify-between ${activePage === link.id ? 'text-red-600' : 'text-blue-900'}`}
            >
              {link.label} <ChevronRight className="opacity-30" />
            </button>
          ))}
          <div className="pt-8 space-y-4">
            <a href={`tel:${CONTACT_INFO.phone}`} className="flex items-center text-blue-900 font-bold text-lg"><Phone className="mr-3 text-red-600" /> {CONTACT_INFO.phone}</a>
            <button onClick={() => handleLinkClick('contact')} className="w-full bg-red-600 text-white py-5 rounded-2xl font-black text-xl shadow-2xl">Book Free Visit</button>
          </div>
        </div>
      )}
    </nav>
  );
};

// --- FAQ Component ---

const FAQItem = ({ item }: { item: { q: string, a: string } }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-gray-200 py-6">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left gap-4"
      >
        <h4 className="text-lg md:text-xl font-bold text-blue-900">{item.q}</h4>
        <div className={`p-1.5 rounded-full ${isOpen ? 'bg-red-100' : 'bg-gray-100'} transition-colors`}>
          {isOpen ? <Minus className="w-5 h-5 text-red-600" /> : <Plus className="w-5 h-5 text-blue-900" />}
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96 mt-4 opacity-100' : 'max-h-0 opacity-0'}`}>
        <p className="text-gray-600 leading-relaxed text-lg">{item.a}</p>
      </div>
    </div>
  );
};

// --- Page Content Components ---

const Home = ({ setActivePage }: { setActivePage: (p: string) => void }) => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1516216628859-9bccecad13ec?auto=format&fit=crop&q=80&w=1920" 
            className="w-full h-full object-cover" 
            alt="Fire Safety Hero" 
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/95 via-blue-900/80 to-transparent"></div>
        </div>

        <div className="container mx-auto px-4 lg:px-8 z-10 text-white">
          <div className="max-w-4xl pt-20">
            <div className="flex items-center gap-3 mb-8">
              <span className="bg-red-600 text-white px-5 py-2 rounded-lg text-sm font-black tracking-[0.2em] uppercase shadow-lg shadow-red-600/30">
                Authorized Grade-A Provider
              </span>
              <div className="h-0.5 w-12 bg-white/30 hidden sm:block"></div>
            </div>
            <h1 className="text-2xl md:text-4xl lg:text-5xl font-black mb-8 leading-[1.2] tracking-tight">
              Complete <span className="text-red-500">Fire & Safety</span> <br /> Solutions by Zed-King
            </h1>
            <p className="text-base md:text-lg text-gray-200 mb-12 leading-relaxed font-medium max-w-2xl">
              Professional Grade Installation, Government Certification, and Hands-on Staff Training. We engineer safety for critical industrial assets.
            </p>
            <div className="flex flex-col sm:flex-row gap-6">
              <button 
                onClick={() => { setActivePage('services'); window.scrollTo(0,0); }}
                className="bg-red-600 hover:bg-red-700 text-white px-10 py-4 rounded-2xl font-black text-xl shadow-2xl flex items-center justify-center transition-all transform hover:-translate-y-2 hover:shadow-red-600/40"
              >
                Explore Services <ArrowRight className="ml-3 w-6 h-6" />
              </button>
              <button 
                onClick={() => { setActivePage('contact'); window.scrollTo(0,0); }}
                className="bg-white/10 backdrop-blur-md border-2 border-white/20 hover:bg-white/20 text-white px-10 py-4 rounded-2xl font-black text-xl shadow-2xl transition-all transform hover:-translate-y-2"
              >
                Free Safety Audit
              </button>
            </div>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce hidden md:block">
          <div className="w-8 h-12 border-2 border-white/30 rounded-full flex justify-center p-2">
            <div className="w-1 h-3 bg-white rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Trust Stats Bar */}
      <section className="bg-white py-16 border-b border-gray-100">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
            {[
              { label: 'Years Experience', val: '12+', icon: Calendar },
              { label: 'Success Projects', val: '650+', icon: CheckCircle },
              { label: 'Safety Experts', val: '45+', icon: Users },
              { label: 'Approvals', val: 'Grade-A', icon: Award },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center text-center group">
                <div className="bg-red-50 p-4 rounded-2xl mb-4 group-hover:bg-red-600 transition-colors duration-300">
                  <stat.icon className="w-8 h-8 text-red-600 group-hover:text-white transition-colors" />
                </div>
                <div className="text-4xl font-black text-blue-900">{stat.val}</div>
                <div className="text-sm font-bold text-gray-400 uppercase tracking-widest mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Highlights */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4 lg:px-8">
          <SectionTitle 
            title="Fire Protection Engineering" 
            subtitle="Industry-leading solutions for factories, residential complexes, and high-rise commercial structures." 
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {SERVICES.slice(0, 6).map((s) => (
              <div key={s.id} className="bg-white p-10 rounded-[2.5rem] shadow-sm hover:shadow-2xl border border-gray-100 transition-all duration-500 group relative overflow-hidden flex flex-col">
                <div className="absolute top-0 right-0 w-32 h-32 bg-red-50 rounded-bl-[100px] -mr-8 -mt-8 group-hover:bg-red-600 transition-colors duration-500"></div>
                <div className="mb-10 relative z-10">
                  <div className="w-20 h-20 bg-blue-900 rounded-2xl flex items-center justify-center text-white shadow-xl group-hover:scale-110 transition-transform">
                    {s.id === 'extinguishers' && <Flame />}
                    {s.id === 'alarms' && <Bell />}
                    {s.id === 'hydrants' && <Droplets />}
                    {s.id === 'amc' && <Settings />}
                    {s.id === 'training' && <GraduationCap />}
                    {s.id === 'noc' && <FileCheck />}
                  </div>
                </div>
                <h3 className="text-2xl font-black text-blue-900 mb-4 pr-10">{s.title}</h3>
                <p className="text-gray-600 mb-8 text-lg leading-relaxed">{s.description}</p>
                <div className="mt-auto pt-6 border-t border-gray-50">
                  <button 
                    onClick={() => { setActivePage('services'); window.scrollTo(0,0); }}
                    className="flex items-center text-red-600 font-black tracking-widest uppercase text-xs hover:gap-4 transition-all"
                  >
                    Service Details <ArrowRight className="ml-2 w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-16 text-center">
             <button 
              onClick={() => { setActivePage('services'); window.scrollTo(0,0); }}
              className="bg-blue-900 text-white px-10 py-4 rounded-xl font-black hover:bg-blue-800 transition-colors shadow-lg"
            >
              Explore All Services
            </button>
          </div>
        </div>
      </section>

      {/* Corporate Clients Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8 text-center">
          <SectionTitle title="Trusted by Global Enterprises" subtitle="We are proud partners with industry leaders across various sectors." />
          <div className="flex flex-wrap justify-center items-center gap-12 lg:gap-24 grayscale opacity-40 hover:grayscale-0 hover:opacity-100 transition-all duration-700">
            {CLIENTS.map(c => (
              <img key={c.name} src={c.logo} alt={c.name} className="h-12 md:h-16 w-auto object-contain" />
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Feature */}
      <section className="py-20 bg-red-600 text-white">
        <div className="container mx-auto px-4 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-6">
            <div className="bg-white/20 p-5 rounded-full animate-pulse"><PhoneCall className="w-10 h-10" /></div>
            <div>
              <h3 className="text-3xl font-black">Emergency On-Call Support</h3>
              <p className="text-red-100 text-xl">Technical support available 24/7 for all AMC clients.</p>
            </div>
          </div>
          <div className="text-4xl font-black bg-white text-red-600 px-10 py-5 rounded-3xl shadow-2xl cursor-pointer hover:bg-gray-100 transition-colors" onClick={() => window.location.href = `tel:${CONTACT_INFO.phone}`}>
            {CONTACT_INFO.emergency}
          </div>
        </div>
      </section>
    </div>
  );
};

const GalleryPage = () => (
  <section className="py-32 bg-white">
    <div className="container mx-auto px-4">
      <SectionTitle title="Real Projects, Real Safety" subtitle="Browse through our high-quality installation and safety training sessions." />
      <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
        {GALLERY.map(item => (
          <div key={item.id} className="relative group rounded-3xl overflow-hidden shadow-xl cursor-pointer">
            <img src={item.image} alt={item.type} className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-8 flex flex-col justify-end">
              <span className="bg-red-600 text-white px-3 py-1 rounded-full text-xs font-bold w-fit mb-2">{item.type}</span>
              <p className="text-white font-bold text-lg">On-site Quality Execution</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const BlogSection = () => (
  <section className="py-32 bg-gray-50">
    <div className="container mx-auto px-4">
      <SectionTitle title="Fire Safety Insights" subtitle="Stay updated with the latest safety protocols and equipment guides." />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {BLOG_POSTS.map(post => (
          <div key={post.id} className="bg-white rounded-[2rem] overflow-hidden shadow-lg border border-gray-100 hover:-translate-y-2 transition-transform duration-300">
            <div className="h-48 bg-gray-200 overflow-hidden">
               <img src={`https://images.unsplash.com/photo-1599708141690-d81b3021975e?auto=format&fit=crop&q=80&w=600&sig=${post.id}`} alt={post.title} className="w-full h-full object-cover" />
            </div>
            <div className="p-8">
              <div className="flex items-center text-sm text-gray-400 mb-4 font-bold">
                <Calendar className="w-4 h-4 mr-2" /> {post.date}
              </div>
              <h3 className="text-2xl font-black text-blue-900 mb-4 line-clamp-2">{post.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{post.excerpt}</p>
              <button className="text-red-600 font-black uppercase text-sm flex items-center hover:gap-2 transition-all">Read Article <ArrowRight className="ml-2 w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// --- Main App Root ---

export default function App() {
  const [activePage, setActivePage] = useState('home');

  const handleLinkClick = (id: string) => {
    setActivePage(id);
    window.scrollTo(0, 0);
  };

  const renderPage = () => {
    switch(activePage) {
      case 'home': return <Home setActivePage={setActivePage} />;
      case 'services': return (
        <section className="py-32 bg-gray-50">
          <div className="container mx-auto px-4">
            <SectionTitle title="Industrial Grade Services" subtitle="Specialized solutions for every critical infrastructure." />
            <div className="grid grid-cols-1 gap-16">
              {SERVICES.map((s, idx) => (
                <div key={s.id} className={`flex flex-col lg:flex-row items-center gap-12 bg-white rounded-[3rem] p-8 lg:p-12 shadow-xl border border-gray-100 ${idx % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                  <div className="lg:w-1/2 rounded-[2rem] overflow-hidden shadow-2xl h-96">
                    <img src={s.image} alt={s.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="lg:w-1/2 space-y-6">
                    <div className="flex items-center gap-4">
                      <div className="p-4 bg-red-600 rounded-2xl text-white shadow-lg">
                        {s.id === 'extinguishers' && <Flame />}
                        {s.id === 'alarms' && <Bell />}
                        {s.id === 'hydrants' && <Droplets />}
                        {s.id === 'amc' && <Settings />}
                        {s.id === 'training' && <GraduationCap />}
                        {s.id === 'noc' && <FileCheck />}
                      </div>
                      <h3 className="text-3xl md:text-4xl font-black text-blue-900">{s.title}</h3>
                    </div>
                    <p className="text-xl text-gray-600 leading-relaxed">{s.longDescription}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6">
                      <div className="bg-gray-50 p-6 rounded-2xl">
                        <h4 className="text-red-600 font-black uppercase text-xs tracking-widest mb-4 flex items-center"><Award className="w-4 h-4 mr-2" /> Key Features</h4>
                        <ul className="space-y-3">
                          {s.benefits.map(b => <li key={b} className="flex items-center text-blue-900 font-bold"><CheckCircle className="w-4 h-4 mr-2 text-green-500" /> {b}</li>)}
                        </ul>
                      </div>
                      <div className="bg-gray-50 p-6 rounded-2xl">
                        <h4 className="text-red-600 font-black uppercase text-xs tracking-widest mb-4 flex items-center"><Info className="w-4 h-4 mr-2" /> Sectors</h4>
                        <ul className="space-y-3">
                          {s.industries.map(i => <li key={i} className="flex items-center text-blue-900 font-bold"><ChevronRight className="w-4 h-4 mr-1 text-red-300" /> {i}</li>)}
                        </ul>
                      </div>
                    </div>
                    <div className="pt-6">
                      <button onClick={() => handleLinkClick('contact')} className="bg-blue-900 text-white px-10 py-4 rounded-xl font-black shadow-lg hover:bg-red-600 transition-colors">Book Consultation</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      );
      case 'gallery': return <GalleryPage />;
      case 'projects': return (
        <section className="py-32 bg-white">
          <div className="container mx-auto px-4">
            <SectionTitle title="Corporate Case Studies" subtitle="A visual journey through our large-scale safety deployments." />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {PROJECTS.map(p => (
                <div key={p.id} className="group relative rounded-[2.5rem] overflow-hidden h-[400px] shadow-2xl">
                  <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-900 via-blue-900/10 to-transparent p-12 flex flex-col justify-end">
                    <span className="bg-red-600 text-white px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest w-fit mb-4">{p.industry}</span>
                    <h3 className="text-3xl font-black text-white mb-2">{p.title}</h3>
                    <p className="text-white/70 text-lg flex items-center"><MapPin className="w-5 h-5 mr-2 text-red-500" /> {p.location}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      );
      case 'contact': return (
        <div>
          <ContactPage />
          <section className="pb-32 bg-white">
            <div className="container mx-auto px-4 max-w-4xl">
              <SectionTitle title="Frequently Asked" subtitle="Common safety concerns and our expert answers." />
              <div className="bg-white rounded-3xl">
                {FAQ.map((item, i) => <FAQItem key={i} item={item} />)}
              </div>
            </div>
          </section>
        </div>
      );
      case 'about': return (
        <section className="py-32 bg-white">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-20 items-center">
              <div className="lg:w-1/2 space-y-8">
                <div className="bg-red-50 p-6 rounded-3xl border border-red-100 inline-block">
                  <span className="text-red-600 font-black tracking-widest uppercase">Since 2012</span>
                </div>
                <h2 className="text-5xl md:text-7xl font-black text-blue-900 leading-[1.1]">The Name You Trust For <span className="text-red-600">Total Protection.</span></h2>
                <p className="text-2xl text-gray-600 leading-relaxed">
                  We don't just sell equipment; we build resilient safety architectures. With over 12 years of core engineering experience, Zed-King Fire and Safety is the gold standard in life safety.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 py-8 border-y border-gray-100">
                  <div>
                    <h4 className="text-blue-900 font-black text-xl mb-4">Our Vision</h4>
                    <p className="text-gray-500">To make India disaster-resilient through innovation, training, and zero-compromise safety standards.</p>
                  </div>
                  <div>
                    <h4 className="text-blue-900 font-black text-xl mb-4">Our Mission</h4>
                    <p className="text-gray-500">Providing end-to-end fire safety management for high-risk assets using cutting-edge IoT and hardware.</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-12">
                   {CERTIFICATIONS.map((cert, i) => (
                      <div key={i} className="flex items-center gap-4 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all">
                        <img src={cert.image} alt={cert.title} className="w-12 h-12" />
                        <div>
                          <p className="font-black text-blue-900 text-sm uppercase">{cert.title}</p>
                          <p className="text-xs text-gray-400 font-bold">{cert.issuer}</p>
                        </div>
                      </div>
                   ))}
                </div>
              </div>
              <div className="lg:w-1/2 relative">
                <div className="bg-red-600 w-full h-full absolute top-8 left-8 rounded-[3rem] -z-10"></div>
                <img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&q=80&w=1000" alt="Our Team" className="rounded-[3rem] shadow-2xl" />
                <div className="absolute -bottom-10 -left-10 bg-white p-10 rounded-3xl shadow-2xl border border-gray-100">
                  <p className="text-6xl font-black text-red-600">12+</p>
                  <p className="font-bold text-blue-900 uppercase tracking-widest">Years of Trust</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      );
      default: return <Home setActivePage={setActivePage} />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar activePage={activePage} setActivePage={setActivePage} />
      
      <main>
        {renderPage()}
        {activePage === 'home' && <BlogSection />}
      </main>

      {/* Footer */}
      <footer className="bg-blue-950 text-white pt-32 pb-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
            <div className="space-y-8">
              <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleLinkClick('home')}>
                <div className="bg-red-600 p-2.5 rounded-xl"><ShieldCheck className="text-white w-7 h-7" /></div>
                <div className="flex flex-col">
                  <span className="text-2xl font-black tracking-tighter">ZED-KING</span>
                  <span className="text-[10px] font-bold text-red-600 tracking-wider">Fire and Safety</span>
                </div>
              </div>
              <p className="text-gray-400 text-lg leading-relaxed">
                ISO 9001:2015 certified leader in Fire Safety Engineering. We provide total peace of mind through BIS approved technologies and Grade-A expertise.
              </p>
              <div className="flex gap-4">
                {['fb', 'tw', 'ln', 'ig'].map(s => <div key={s} className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-red-600 hover:border-red-600 transition-all cursor-pointer group"><Search className="w-5 h-5 text-gray-400 group-hover:text-white" /></div>)}
              </div>
            </div>

            <div>
              <h4 className="text-xl font-black mb-8 border-b border-white/10 pb-4">Navigation</h4>
              <ul className="space-y-4 text-gray-400 text-lg">
                {[
                  { id: 'home', label: 'Home' },
                  { id: 'services', label: 'Services' },
                  { id: 'about', label: 'About Us' },
                  { id: 'gallery', label: 'Gallery' },
                  { id: 'projects', label: 'Our Work' },
                  { id: 'contact', label: 'Contact' }
                ].map(link => (
                  <li key={link.id} onClick={() => handleLinkClick(link.id)} className="hover:text-red-500 transition-colors cursor-pointer flex items-center group">
                    <ChevronRight className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform" /> {link.label}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-xl font-black mb-8 border-b border-white/10 pb-4">Major Services</h4>
              <ul className="space-y-4 text-gray-400 text-lg">
                {SERVICES.map(s => (
                  <li key={s.id} onClick={() => handleLinkClick('services')} className="hover:text-red-500 transition-colors cursor-pointer">{s.title}</li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-xl font-black mb-8 border-b border-white/10 pb-4">Official Contact</h4>
              <ul className="space-y-6 text-gray-400">
                <li className="flex gap-4">
                  <MapPin className="text-red-600 w-6 h-6 shrink-0" />
                  <span className="text-lg">{CONTACT_INFO.address}</span>
                </li>
                <li className="flex gap-4 cursor-pointer" onClick={() => window.location.href = `tel:${CONTACT_INFO.phone}`}>
                  <Phone className="text-red-600 w-6 h-6 shrink-0" />
                  <span className="text-lg font-black text-white">{CONTACT_INFO.phone}</span>
                </li>
                <li className="flex gap-4 cursor-pointer" onClick={() => window.location.href = `mailto:${CONTACT_INFO.email}`}>
                  <Mail className="text-red-600 w-6 h-6 shrink-0" />
                  <span className="text-lg">{CONTACT_INFO.email}</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/5 pt-12 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-gray-500 text-sm font-bold tracking-widest uppercase">
              &copy; {new Date().getFullYear()} Zed-King Fire and Safety. All Rights Reserved.
            </p>
            <button className="flex items-center gap-2 text-white/40 hover:text-white transition-colors uppercase text-xs font-black tracking-widest">
              <Lock className="w-4 h-4" /> Admin Portal Login
            </button>
          </div>
        </div>
      </footer>

      {/* Persistent Action Hub */}
      <div className="fixed bottom-10 right-10 flex flex-col space-y-6 z-40">
        <a 
          href={`https://wa.me/${CONTACT_INFO.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 text-white p-5 rounded-3xl shadow-[0_20px_50px_rgba(34,197,94,0.4)] hover:scale-110 active:scale-95 transition-all group relative"
          title="Chat on WhatsApp"
        >
          <span className="absolute right-full mr-4 bg-white text-green-600 px-4 py-2 rounded-xl text-sm font-black shadow-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">Chat With Us</span>
          <MessageCircle className="w-8 h-8" />
        </a>
        <a 
          href={`tel:${CONTACT_INFO.phone}`}
          className="bg-red-600 text-white p-5 rounded-3xl shadow-[0_20px_50px_rgba(220,38,38,0.4)] hover:scale-110 active:scale-95 transition-all group relative"
          title="Direct Call"
        >
          <span className="absolute right-full mr-4 bg-white text-red-600 px-4 py-2 rounded-xl text-sm font-black shadow-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">Immediate Call</span>
          <Phone className="w-8 h-8" />
        </a>
      </div>
    </div>
  );
}

const ContactPage = () => {
  const [submitted, setSubmitted] = useState(false);

  return (
    <section className="py-32 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          <div>
            <span className="text-red-600 font-black tracking-[0.3em] uppercase text-sm mb-6 block">Inquiry Channel</span>
            <h2 className="text-4xl md:text-6xl font-black text-blue-900 mb-8 leading-tight">Let's Secure <br />Your Facility.</h2>
            <p className="text-xl text-gray-500 mb-12">Submit your details for a technical consultation. We respond within 4 business hours.</p>
            
            <div className="space-y-10">
              <div className="flex gap-6 cursor-pointer" onClick={() => window.location.href = `tel:${CONTACT_INFO.phone}`}>
                <div className="bg-white p-5 rounded-3xl shadow-xl"><Phone className="text-red-600 w-8 h-8" /></div>
                <div>
                  <h4 className="text-gray-400 font-black uppercase text-xs tracking-widest mb-1">Corporate Hotline</h4>
                  <p className="text-2xl font-black text-blue-900">{CONTACT_INFO.phone}</p>
                </div>
              </div>
              <div className="flex gap-6 cursor-pointer" onClick={() => window.location.href = `mailto:${CONTACT_INFO.email}`}>
                <div className="bg-white p-5 rounded-3xl shadow-xl"><Mail className="text-red-600 w-8 h-8" /></div>
                <div>
                  <h4 className="text-gray-400 font-black uppercase text-xs tracking-widest mb-1">Project Inquiries</h4>
                  <p className="text-2xl font-black text-blue-900">{CONTACT_INFO.email}</p>
                </div>
              </div>
              <div className="flex gap-6">
                <div className="bg-white p-5 rounded-3xl shadow-xl"><Clock className="text-red-600 w-8 h-8" /></div>
                <div>
                  <h4 className="text-gray-400 font-black uppercase text-xs tracking-widest mb-1">Office Hours</h4>
                  <p className="text-2xl font-black text-blue-900">{CONTACT_INFO.workingHours}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-12 lg:p-16 rounded-[3rem] shadow-2xl border border-gray-100">
            {submitted ? (
              <div className="text-center py-20">
                <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner"><CheckCircle className="text-green-600 w-12 h-12" /></div>
                <h3 className="text-4xl font-black text-blue-900 mb-4">Request Received!</h3>
                <p className="text-xl text-gray-500 leading-relaxed">A safety advisor has been assigned to your request and will call you shortly.</p>
                <button onClick={() => setSubmitted(false)} className="mt-12 text-red-600 font-black text-sm uppercase tracking-widest border-b-2 border-red-600 pb-1">Submit Another Query</button>
              </div>
            ) : (
              <form onSubmit={(e) => {e.preventDefault(); setSubmitted(true);}} className="space-y-8">
                <div className="space-y-2">
                  <label className="text-xs font-black text-blue-900 uppercase tracking-widest">Full Name</label>
                  <input required type="text" className="w-full bg-gray-50 border-2 border-transparent focus:border-red-600 focus:bg-white p-5 rounded-2xl outline-none transition-all text-lg font-bold text-blue-900" placeholder="Your Name" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-blue-900 uppercase tracking-widest">Mobile Number</label>
                    <input required type="tel" className="w-full bg-gray-50 border-2 border-transparent focus:border-red-600 focus:bg-white p-5 rounded-2xl outline-none transition-all text-lg font-bold text-blue-900" placeholder="+91 XXXXX XXXXX" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-blue-900 uppercase tracking-widest">Required Service</label>
                    <select required className="w-full bg-gray-50 border-2 border-transparent focus:border-red-600 focus:bg-white p-5 rounded-2xl outline-none transition-all text-lg font-bold text-blue-900 appearance-none cursor-pointer">
                      <option value="" className="text-blue-900">Select Service</option>
                      {SERVICES.map(s => <option key={s.id} value={s.id} className="text-blue-900">{s.title}</option>)}
                      <option value="audit" className="text-blue-900">Safety Audit</option>
                      <option value="noc" className="text-blue-900">Fire NOC</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-blue-900 uppercase tracking-widest">Site Requirements</label>
                  <textarea rows={4} className="w-full bg-gray-50 border-2 border-transparent focus:border-red-600 focus:bg-white p-5 rounded-2xl outline-none transition-all text-lg font-bold text-blue-900" placeholder="Tell us about your facility..."></textarea>
                </div>
                <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white py-6 rounded-3xl font-black text-2xl shadow-2xl hover:shadow-red-600/30 transition-all transform active:scale-95">
                  Confirm Inquiry
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
